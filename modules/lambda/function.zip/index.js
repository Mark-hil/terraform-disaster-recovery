exports.handler = async (event) => {
  const AWS = require('aws-sdk');
  const ec2 = new AWS.EC2();
  const rds = new AWS.RDS();
  const elbv2 = new AWS.ELBv2();
  const sns = new AWS.SNS();

  try {
    // Stop primary EC2 instance
    await ec2.stopInstances({
      InstanceIds: [process.env.PRIMARY_INSTANCE_ID]
    }).promise();

    // Start DR EC2 instance
    await ec2.startInstances({
      InstanceIds: [process.env.DR_INSTANCE_ID]
    }).promise();

    // Promote DR RDS instance
    await rds.promoteReadReplica({
      DBInstanceIdentifier: process.env.DR_RDS_ARN.split(':')[6]
    }).promise();

    // Wait for instance to be available
    await new Promise(resolve => setTimeout(resolve, 60000));

    // Deregister primary instance from target group
    await elbv2.deregisterTargets({
      TargetGroupArn: process.env.PRIMARY_TARGET_GROUP_ARN,
      Targets: [{ Id: process.env.PRIMARY_INSTANCE_ID }]
    }).promise();

    // Register DR instance with target group
    await elbv2.registerTargets({
      TargetGroupArn: process.env.DR_TARGET_GROUP_ARN,
      Targets: [{ Id: process.env.DR_INSTANCE_ID }]
    }).promise();

    // Send notification
    await sns.publish({
      TopicArn: process.env.SNS_TOPIC_ARN,
      Subject: 'DR Failover Complete',
      Message: 'Successfully failed over to DR environment'
    }).promise();

    return {
      statusCode: 200,
      body: JSON.stringify('Failover completed successfully')
    };
  } catch (error) {
    console.error('Error:', error);
    
    // Send failure notification
    await sns.publish({
      TopicArn: process.env.SNS_TOPIC_ARN,
      Subject: 'DR Failover Failed',
      Message: 'Failover failed: ' + error.message
    }).promise();

    throw error;
  }
};
